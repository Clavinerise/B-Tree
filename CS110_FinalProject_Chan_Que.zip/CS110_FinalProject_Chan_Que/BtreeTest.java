
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.*;

public class BtreeTest {
    
    private Btree atree;
    private Btree ctree;
    
    public BtreeTest() {
       
    }
    
    @Before
    public void setUp() {
         atree = new Btree(7);
         ctree = new Btree(7);
         // ctree has a height of 3
         for(int i = 0; i<=31; i++) {
             ctree.insert(ctree.root, i+1, i);
         }
    }

    @Test
    public void testInsert() {
        
        // insert key 1 with valfile offset 0 to atree
        atree.insert(atree.root, 1, 0);
        assertEquals(0, atree.root.record);
        assertEquals(1, atree.root.keyPointer);
        assertEquals(1, atree.root.childPointer);
        assertEquals(false, atree.root.isFull());
        assertEquals(false, atree.root.hasChild());
        assertEquals(false, atree.root.hasParent());
        assertEquals((long) 1, (long) atree.root.key[0][0]);
        assertEquals((long) 0, (long) atree.root.key[0][1]);
        
        // insert key 2 with valfile offset 1 to atree
        atree.insert(atree.root, 2, 1);
        // insert key 5 with valfile offset 4 to atree
        atree.insert(atree.root, 5, 4);
        assertEquals(0, atree.root.record);
        assertEquals(3, atree.root.keyPointer);
        assertEquals(1, atree.root.childPointer);
        assertEquals(false, atree.root.isFull());
        assertEquals(false, atree.root.hasChild());
        assertEquals(false, atree.root.hasParent());
        assertEquals((long) 5, (long) atree.root.key[2][0]);
        assertEquals((long) 4, (long) atree.root.key[2][1]);
        
        // insert key 3 with valfile offset 2 to atree
        // this key should become the 3rd key while key 5 becomes the 4th
        atree.insert(atree.root, 3, 2);
        assertEquals(0, atree.root.record);
        assertEquals(4, atree.root.keyPointer);
        assertEquals(1, atree.root.childPointer);
        assertEquals(false, atree.root.isFull());
        assertEquals(false, atree.root.hasChild());
        assertEquals(false, atree.root.hasParent());
        assertEquals((long) 3, (long) atree.root.key[2][0]);
        assertEquals((long) 2, (long) atree.root.key[2][1]);
        assertEquals((long) 5, (long) atree.root.key[3][0]);
        assertEquals((long) 4, (long) atree.root.key[3][1]);
        
        // insert key 4 with valfile offset 3 to atree
        // this key should become the 4th key while key 5 becomes the 5th
        atree.insert(atree.root, 4, 3);
        assertEquals(0, atree.root.record);
        assertEquals(5, atree.root.keyPointer); // we now have 5 keys
        assertEquals(1, atree.root.childPointer);
        assertEquals(false, atree.root.isFull());
        assertEquals(false, atree.root.hasChild());
        assertEquals(false, atree.root.hasParent());
        assertEquals((long) 4, (long) atree.root.key[3][0]);
        assertEquals((long) 3, (long) atree.root.key[3][1]);
        assertEquals((long) 5, (long) atree.root.key[4][0]);
        assertEquals((long) 4, (long) atree.root.key[4][1]);
        
        // insert 2 more keys
        // we now have 7 keys which means the node is full
        atree.insert(atree.root, 6, 5);
        atree.insert(atree.root, 10, 10);
        assertEquals(1, atree.root.record);
        assertEquals(1, atree.root.keyPointer); // back to 1 key
        assertEquals(2, atree.root.childPointer); // now has 2 children
        assertEquals(false, atree.root.isFull()); 
        assertEquals(true, atree.root.hasChild()); // true
        assertEquals(false, atree.root.hasParent());
        assertEquals((long) 4, (long) atree.root.key[0][0]);
        assertEquals((long) 3, (long) atree.root.key[0][1]);
        assertEquals(null, atree.root.key[1][0]); // no second key
        assertEquals(null, atree.root.key[1][1]); // no second key valfile offset
        
        assertEquals(0, atree.root.child[0].record); // first child has record 1
        assertEquals(2, atree.root.child[1].record); // second child has record 2
        assertEquals(3, atree.root.child[0].keyPointer); // 3 keys
        assertEquals(3, atree.root.child[1].keyPointer); // 3 keys
        assertEquals(false, atree.root.child[0].hasChild()); // no children
        assertEquals(true, atree.root.child[0].hasParent()); // has parent
        assertEquals(false, atree.root.child[1].hasChild()); // no children
        assertEquals(true, atree.root.child[1].hasParent()); // has parent
        assertEquals((long) 1, (long) atree.root.child[0].key[0][0]);
        assertEquals((long) 0, (long) atree.root.child[0].key[0][1]);
        assertEquals((long) 3, (long) atree.root.child[0].key[2][0]);
        assertEquals((long) 2, (long) atree.root.child[0].key[2][1]);
        assertEquals((long) 5, (long) atree.root.child[1].key[0][0]);
        assertEquals((long) 4, (long) atree.root.child[1].key[0][1]);
        assertEquals((long) 10, (long) atree.root.child[1].key[2][0]);
        assertEquals((long) 10, (long) atree.root.child[1].key[2][1]);
        
        // insert a key that is less than the any of the prior keys
        atree.insert(atree.root, 0, 7);
        assertEquals(0, atree.root.child[0].record);
        assertEquals(4, atree.root.child[0].keyPointer); // 4 keys
        assertEquals(false, atree.root.child[0].hasChild()); 
        assertEquals((long) 0, (long) atree.root.child[0].key[0][0]);
        assertEquals((long) 7, (long) atree.root.child[0].key[0][1]);
        assertEquals((long) 1, (long) atree.root.child[0].key[1][0]);
        assertEquals((long) 0, (long) atree.root.child[0].key[1][1]);
        
        // insert a key that is greater than the any of the prior keys
        atree.insert(atree.root, 11, 11);
        assertEquals(2, atree.root.child[1].record);
        assertEquals(4, atree.root.child[1].keyPointer); // 4 keys
        assertEquals(false, atree.root.child[0].hasChild()); 
        assertEquals((long) 11, (long) atree.root.child[1].key[3][0]);
        assertEquals((long) 11, (long) atree.root.child[1].key[3][1]);
        
        // insert a key that should be inserted between keys in child node
        atree.insert(atree.root, 7, 6);
        assertEquals(2, atree.root.child[1].record);
        assertEquals(5, atree.root.child[1].keyPointer); // 5 keys
        assertEquals((long) 7, (long) atree.root.child[1].key[2][0]);
        assertEquals((long) 6, (long) atree.root.child[1].key[2][1]);
        assertEquals((long) 10, (long) atree.root.child[1].key[3][0]);
        assertEquals((long) 10, (long) atree.root.child[1].key[3][1]);
        
        // fill child node
        atree.insert(atree.root, 12, 12);
        atree.insert(atree.root, 13, 13);
        assertEquals(1, atree.root.record);
        assertEquals(2, atree.root.keyPointer); // 2 keys
        assertEquals(3, atree.root.childPointer); // now has 3 children
        assertEquals(false, atree.root.isFull()); 
        assertEquals(true, atree.root.hasChild()); // true
        assertEquals(false, atree.root.hasParent());
        assertEquals((long) 4, (long) atree.root.key[0][0]);
        assertEquals((long) 3, (long) atree.root.key[0][1]);
        assertEquals((long) 10, (long) atree.root.key[1][0]);
        assertEquals((long) 10, (long) atree.root.key[1][1]);
        assertEquals(null, atree.root.key[3][0]); // no third key
        assertEquals(null, atree.root.key[3][1]); // no third key valfile offset
        
        // new children nodes
        // first child did not change
        assertEquals(0, atree.root.child[0].record); // first child has record 1
        assertEquals(4, atree.root.child[0].keyPointer); // 4 keys
        assertEquals(false, atree.root.child[0].hasChild()); // no children
        assertEquals(true, atree.root.child[0].hasParent()); // has parent
        assertEquals((long) 0, (long) atree.root.child[0].key[0][0]);
        assertEquals((long) 7, (long) atree.root.child[0].key[0][1]);
        assertEquals((long) 3, (long) atree.root.child[0].key[3][0]);
        assertEquals((long) 2, (long) atree.root.child[0].key[3][1]);
        
        // new second child
        assertEquals(2, atree.root.child[1].record); // first child has record 1
        assertEquals(3, atree.root.child[1].keyPointer); // 3 keys
        assertEquals(false, atree.root.child[1].hasChild()); // no children
        assertEquals(true, atree.root.child[1].hasParent()); // has parent
        assertEquals((long) 5, (long) atree.root.child[1].key[0][0]);
        assertEquals((long) 4, (long) atree.root.child[1].key[0][1]);
        assertEquals((long) 7, (long) atree.root.child[1].key[2][0]);
        assertEquals((long) 6, (long) atree.root.child[1].key[2][1]);
        
        // new third child
        assertEquals(2, atree.root.child[1].record); // first child has record 1
        assertEquals(3, atree.root.child[1].keyPointer); // 3 keys
        assertEquals(false, atree.root.child[1].hasChild()); // no children
        assertEquals(true, atree.root.child[1].hasParent()); // has parent
        assertEquals((long) 11, (long) atree.root.child[2].key[0][0]);
        assertEquals((long) 11, (long) atree.root.child[2].key[0][1]);
        assertEquals((long) 13, (long) atree.root.child[2].key[2][0]);
        assertEquals((long) 13, (long) atree.root.child[2].key[2][1]);
        
        // add nodes until tree has height of 3
        for(int i =100; i<=120; i++){
            atree.insert(atree.root, i, i);
        }
        assertEquals(104, (long) atree.root.key[0][0]);
        assertTrue(atree.root.child[0].hasChild());
        assertTrue(atree.root.child[1].hasChild());
        assertFalse(atree.root.child[0].child[0].hasChild());
        assertFalse(atree.root.child[1].child[3].hasChild());
        assertEquals(4, (long) atree.root.child[0].key[0][0]);
        assertEquals(10, (long) atree.root.child[0].key[1][0]);
        assertEquals(100, (long) atree.root.child[0].key[2][0]);
        assertEquals(108, (long) atree.root.child[1].key[0][0]);
        assertEquals(112, (long) atree.root.child[1].key[1][0]);
        assertEquals(116, (long) atree.root.child[0].key[2][0]);
        assertEquals(120, (long) atree.root.child[1].child[3].key[3][0]);
    }

    @Test
    public void testSplit() {
        atree.insert(atree.root, 5, 5);
        atree.insert(atree.root, 6, 6);
        atree.insert(atree.root, 7, 7);
        atree.insert(atree.root, 8, 8);
        atree.insert(atree.root, 9, 9);
        
        // force change the order to allow manual implementation of split() method
        atree.order = 5;
        atree.minKeys = 5/2;
        atree.split(atree.root);
        assertTrue(atree.root.hasChild());
        assertTrue(atree.root.child[0].hasParent());
        assertEquals(2, (long) atree.root.childPointer);
        assertEquals(1, (long) atree.root.keyPointer);
        assertEquals(7, (long) atree.root.key[0][0]);
        assertEquals(5, (long) atree.root.child[0].key[0][0]);
        assertEquals(6, (long) atree.root.child[0].key[1][0]);
        assertEquals(8, (long) atree.root.child[1].key[0][0]);
        assertEquals(9, (long) atree.root.child[1].key[1][0]);
    }

    @Test
    public void testSearchNode() {
        assertEquals(null, ctree.searchNode(ctree.root, 1000)); // search for node that doesn't exist
        assertEquals(ctree.root, ctree.searchNode(ctree.root, 16));
        assertEquals(ctree.root.child[0].child[0], ctree.searchNode(ctree.root, 1));
        assertEquals(ctree.root.child[0].child[3], ctree.searchNode(ctree.root, 15));
        assertEquals(ctree.root.child[1].child[3], ctree.searchNode(ctree.root, 31));
    }

    @Test
    public void testRecNDPos() {
        assertArrayEquals(new int[] {-1, -1} , ctree.recNDPos(100)); // no record and offset
        assertArrayEquals(new int[] {9, 0} , ctree.recNDPos(16)); 
        assertArrayEquals(new int[] {0, 0} , ctree.recNDPos(1));
        assertArrayEquals(new int[] {4, 2} , ctree.recNDPos(15));
        assertArrayEquals(new int[] {8, 2} , ctree.recNDPos(31));
    }

    @Test
    public void testTakeKeys() {
        assertArrayEquals(new long[] {16, -1, -1, -1, -1, -1}, ctree.takeKeys(ctree.root));
        assertArrayEquals(new long[] {4, 8, 12, -1, -1, -1}, ctree.takeKeys(ctree.root.child[0]));
        assertArrayEquals(new long[] {20, 24, 28, -1, -1, -1}, ctree.takeKeys(ctree.root.child[1]));
        assertArrayEquals(new long[] {1, 2, 3, -1, -1, -1}, ctree.takeKeys(ctree.root.child[0].child[0]));
        assertArrayEquals(new long[] {5, 6, 7, -1, -1, -1}, ctree.takeKeys(ctree.root.child[0].child[1]));
        assertArrayEquals(new long[] {9, 10, 11, -1, -1, -1}, ctree.takeKeys(ctree.root.child[0].child[2]));
        assertArrayEquals(new long[] {13, 14, 15, -1, -1, -1}, ctree.takeKeys(ctree.root.child[0].child[3]));
        assertArrayEquals(new long[] {17, 18, 19, -1, -1, -1}, ctree.takeKeys(ctree.root.child[1].child[0]));
        assertArrayEquals(new long[] {21, 22, 23, -1, -1, -1}, ctree.takeKeys(ctree.root.child[1].child[1]));
        assertArrayEquals(new long[] {25, 26, 27, -1, -1, -1}, ctree.takeKeys(ctree.root.child[1].child[2]));
        assertArrayEquals(new long[] {29, 30, 31, 32, -1, -1}, ctree.takeKeys(ctree.root.child[1].child[3]));
    }

    @Test
    public void testTakeOffset() {
        assertArrayEquals(new long[] {15, -1, -1, -1, -1, -1}, ctree.takeOffset(ctree.root));
        assertArrayEquals(new long[] {3, 7, 11, -1, -1, -1}, ctree.takeOffset(ctree.root.child[0]));
        assertArrayEquals(new long[] {19, 23, 27, -1, -1, -1}, ctree.takeOffset(ctree.root.child[1]));
        assertArrayEquals(new long[] {0, 1, 2, -1, -1, -1}, ctree.takeOffset(ctree.root.child[0].child[0]));
        assertArrayEquals(new long[] {4, 5, 6, -1, -1, -1}, ctree.takeOffset(ctree.root.child[0].child[1]));
        assertArrayEquals(new long[] {8, 9, 10, -1, -1, -1}, ctree.takeOffset(ctree.root.child[0].child[2]));
        assertArrayEquals(new long[] {12, 13, 14, -1, -1, -1}, ctree.takeOffset(ctree.root.child[0].child[3]));
        assertArrayEquals(new long[] {16, 17, 18, -1, -1, -1}, ctree.takeOffset(ctree.root.child[1].child[0]));
        assertArrayEquals(new long[] {20, 21, 22, -1, -1, -1}, ctree.takeOffset(ctree.root.child[1].child[1]));
        assertArrayEquals(new long[] {24, 25, 26, -1, -1, -1}, ctree.takeOffset(ctree.root.child[1].child[2]));
        assertArrayEquals(new long[] {28, 29, 30, 31, -1, -1}, ctree.takeOffset(ctree.root.child[1].child[3]));
    }

    @Test
    public void testTakeChildren() {
        //System.out.print(ctree.root.record);
        assertArrayEquals(new long[] {1, 10, -1, -1, -1, -1, -1}, ctree.takeChildren(ctree.root));
        assertArrayEquals(new long[] {0, 2, 3, 4, -1, -1, -1}, ctree.takeChildren(ctree.root.child[0]));
        assertArrayEquals(new long[] {5, 6, 7, 8, -1, -1, -1}, ctree.takeChildren(ctree.root.child[1]));
        assertArrayEquals(new long[] {-1, -1, -1, -1, -1, -1, -1}, ctree.takeChildren(ctree.root.child[0].child[0]));
        assertArrayEquals(new long[] {-1, -1, -1, -1, -1, -1, -1}, ctree.takeChildren(ctree.root.child[0].child[1]));
        assertArrayEquals(new long[] {-1, -1, -1, -1, -1, -1, -1}, ctree.takeChildren(ctree.root.child[0].child[2]));
        assertArrayEquals(new long[] {-1, -1, -1, -1, -1, -1, -1}, ctree.takeChildren(ctree.root.child[0].child[3]));
        assertArrayEquals(new long[] {-1, -1, -1, -1, -1, -1, -1}, ctree.takeChildren(ctree.root.child[1].child[0]));
        assertArrayEquals(new long[] {-1, -1, -1, -1, -1, -1, -1}, ctree.takeChildren(ctree.root.child[1].child[1]));
        assertArrayEquals(new long[] {-1, -1, -1, -1, -1, -1, -1}, ctree.takeChildren(ctree.root.child[1].child[2]));
        assertArrayEquals(new long[] {-1, -1, -1, -1, -1, -1, -1}, ctree.takeChildren(ctree.root.child[1].child[3]));
    }

    @Test
    public void testFindNode() {
        assertEquals(ctree.root, ctree.findNode(ctree.root, 9));
        assertEquals(ctree.root.child[0], ctree.findNode(ctree.root, 1));
        assertEquals(ctree.root.child[1], ctree.findNode(ctree.root, 10));
        assertEquals(ctree.root.child[0].child[0], ctree.findNode(ctree.root, 0));
        assertEquals(ctree.root.child[0].child[1], ctree.findNode(ctree.root, 2));
        assertEquals(ctree.root.child[0].child[2], ctree.findNode(ctree.root, 3));
        assertEquals(ctree.root.child[0].child[3], ctree.findNode(ctree.root, 4));
        assertEquals(ctree.root.child[1].child[0], ctree.findNode(ctree.root, 5));
        assertEquals(ctree.root.child[1].child[1], ctree.findNode(ctree.root, 6));
        assertEquals(ctree.root.child[1].child[2], ctree.findNode(ctree.root, 7));
        assertEquals(ctree.root.child[1].child[3], ctree.findNode(ctree.root, 8));
    }

    @Test
    public void testIsReading() {
        ctree.isReading();
        assertEquals(0, ctree.record);
    }

    @Test
    public void testNodeAdder() {
        // add node
        Long n = new Long(0);
        atree.nodeAdder(new Long[][] {{new Long(4), new Long(1)}, 
            {new Long(-1), new Long(-1)}, {new Long(-1), new Long(-1)}, 
            {new Long(-1), new Long(-1)},{new Long(-1), new Long(-1)},
            {new Long(-1), new Long(-1)}, {new Long(-1), new Long(-1)}}, 1, -1);
        assertEquals(1, atree.root.record);
        assertEquals(false, atree.root.hasParent());
        assertEquals(1, atree.root.keyPointer);
        assertEquals(4, (long) atree.root.key[0][0]);
        assertEquals(1, (long) atree.root.key[0][1]);
        assertNull(atree.root.key[1][0]);
        assertNull(atree.root.key[1][1]);
        
        // add child node of previous node
        atree.nodeAdder(new Long[][] {{new Long(1), new Long(2)}, 
            {new Long(2), new Long(3)}, {new Long(3), new Long(4)}, 
            {new Long(-1), new Long(-1)},{new Long(-1), new Long(-1)},
            {new Long(-1), new Long(-1)}, {new Long(-1), new Long(-1)}}, 0, 1);
        assertEquals(true, atree.root.hasChild());
        assertEquals(3, atree.root.child[0].keyPointer); // 3 keys
        assertEquals(true, atree.root.child[0].hasParent());
        assertEquals(1, (long) atree.root.child[0].key[0][0]);
        assertEquals(2, (long) atree.root.child[0].key[0][1]);
        assertEquals(2, (long) atree.root.child[0].key[1][0]);
        assertEquals(3, (long) atree.root.child[0].key[1][1]);
        assertEquals(3, (long) atree.root.child[0].key[2][0]);
        assertEquals(4, (long) atree.root.child[0].key[2][1]);
        
        // add another child node of root node
        atree.nodeAdder(new Long[][] {{new Long(5), new Long(6)}, 
            {new Long(6), new Long(7)}, {new Long(7), new Long(8)}, 
            {new Long(8), new Long(9)},{new Long(9), new Long(10)},
            {new Long(-1), new Long(-1)}, {new Long(-1), new Long(-1)}}, 2, 1);
        assertEquals(true, atree.root.hasChild());
        assertEquals(2, atree.root.childPointer);
        assertEquals(5, atree.root.child[1].keyPointer); // 5 keys
        assertEquals(true, atree.root.child[1].hasParent());
        assertEquals(5, (long) atree.root.child[1].key[0][0]);
        assertEquals(6, (long) atree.root.child[1].key[0][1]);
        assertEquals(6, (long) atree.root.child[1].key[1][0]);
        assertEquals(7, (long) atree.root.child[1].key[1][1]);
        assertEquals(7, (long) atree.root.child[1].key[2][0]);
        assertEquals(8, (long) atree.root.child[1].key[2][1]);
        assertEquals(8, (long) atree.root.child[1].key[3][0]);
        assertEquals(9, (long) atree.root.child[1].key[3][1]);
        assertEquals(9, (long) atree.root.child[1].key[4][0]);
        assertEquals(10, (long) atree.root.child[1].key[4][1]);
    }
    
}
