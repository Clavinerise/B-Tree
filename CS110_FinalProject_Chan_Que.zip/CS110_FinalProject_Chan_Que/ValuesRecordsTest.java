import org.junit.rules.*;
import org.junit.*;
import static org.junit.Assert.*;
import java.io.*;

public class ValuesRecordsTest {
    ValuesRecords valfile;
            
    public ValuesRecordsTest() {
    }
    
    @Before
    public void setUp()throws IOException {
        // NOTE: remove val if ever it exists in directory
        valfile = new ValuesRecords("val");
    }

    @Test
    public void testAccess() throws Exception {
        valfile.access(0);
        assertEquals(8, valfile.valfile.getFilePointer());
        valfile.access(1);
        assertEquals(266, valfile.valfile.getFilePointer());
        valfile.access(2);
        assertEquals(524, valfile.valfile.getFilePointer());
    }

    @Test
    public void testWrite() throws Exception {
        valfile.write("hello");
        assertEquals(15,valfile.valfile.length()); // 8 bytes for the count, 2 bytes for the short, 5 bytes for string
    }

    @Test
    public void testReadValue() throws Exception {
        valfile.valfile.seek(0);
        assertEquals("", valfile.readValue());
        valfile.valfile.seek(8);
        assertEquals("hello", valfile.readValue());
    }

    @Test
    public void testClose() throws Exception {
    }
    
}
